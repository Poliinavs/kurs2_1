#pragma once
#include <iostream>
#include <cstring>
using namespace std;

#include "FST.h"