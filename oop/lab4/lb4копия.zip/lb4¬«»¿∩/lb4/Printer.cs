﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lb4
{
    public class Printer
    {
        public string IAmPrinting(Text_processor someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(WORD someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(Number_of_operation someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(CConficker someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(soft_creator someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(Soft someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(Virus someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(Saper someobj)
        {
            return someobj.ToString();
        }
        public string IAmPrinting(Game someobj)
        {
            return someobj.ToString();
        }

    }
}
