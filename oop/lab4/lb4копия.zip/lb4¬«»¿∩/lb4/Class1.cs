﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lb4
{
    class A { }
    class B : A { }
    class C : B { }
    class D { }
    class Test
    {
     
    }




    }
